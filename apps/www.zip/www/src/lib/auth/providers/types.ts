export type ProviderUser = {
	id: string;
	username: string;
	email: string;
};
