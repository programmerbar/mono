
import type { Database } from '$lib/db/drizzle';
import { users, type UserInsert } from '$lib/db/schema';

export class UserService {
  #db: Database;

  constructor(db: Database) {
    this.#db = db;
  }

  async findByFeideId(feideId: string) {
    return await this.#db.query.users.findFirst({
      where: (row, { eq }) => eq(row.feideId, feideId)
    });
  }

  async create(user: UserInsert) {
    return await this.#db
      .insert(users)
      .values({ ...user, role: user.role || 'normal' }) // Ensure a default role
      .returning()
      .then((rows) => rows[0]);
  }

  async findAll() {
    return await this.#db.query.users.findMany();
  }

  // Method to update a user's role
  async updateUserRole(userId: string, role: 'normal' | 'board') {
    return await this.#db
      .update(users)
      .set({ role })
      .where((row, { eq }) => eq(row.id, userId))
      .returning()
      .then((rows) => rows[0]);
  }

  // Method to fetch users with specific role
  async findUsersByRole(role: 'normal' | 'board') {
    return await this.#db.query.users.findMany({
      where: (row, { eq }) => eq(row.role, role)
    });
  }
}
