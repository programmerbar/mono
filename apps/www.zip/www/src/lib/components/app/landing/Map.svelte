<div class="h-fit w-full overflow-hidden rounded-xl border shadow-md">
	<iframe
		title="Programmerbar"
		width="100%"
		height="600"
		src="https://maps.google.com/maps?width=100%25&height=600&hl=en&q=Programmerbar,%20Thorm%C3%B8hlens%20Gate%2055,%205006%20Bergen+(Programmerbar)&t=&z=17&ie=UTF8&iwloc=B&output=embed"
	></iframe>
</div>
