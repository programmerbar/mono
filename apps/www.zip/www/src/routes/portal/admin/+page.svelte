<script lang="ts">
	import Heading from '$lib/components/ui/Heading.svelte';
	import { mailto, initials } from '$lib/utils';
	import { invalidate } from '$app/navigation';

	export let data;

	let search = '';
	let currentUserRole = data.user.role; // Get the current user's role

	let boardMembers = data.users.filter((user) => {
		return user.role === 'board' && user.name.toLowerCase().includes(search.toLowerCase());
	});

	let normalMembers = data.users.filter((user) => {
		return user.role === 'normal' && user.name.toLowerCase().includes(search.toLowerCase());
	});

	async function updateRole(userId: string, newRole: string) {
		const formData = new FormData();
		formData.append('userId', userId);
		formData.append('role', newRole);

		await fetch('/portal/admin', {
			method: 'POST',
			body: formData
		});

		await invalidate(); // Refresh data on the page
	}
</script>

<svelte:head>
	<title>Admin - User Management</title>
</svelte:head>

<section class="space-y-6">
	<Heading>Board Members</Heading>
	<ul class="grid grid-cols-1 md:grid-cols-3 gap-4">
		{#each boardMembers as user}
			<li class="block bg-white border rounded-lg p-4">
				<div class="flex justify-center mb-2">
					<div class="w-16 h-16 bg-gray-200 flex items-center justify-center border rounded-full">
						<span class="font-medium text-gray-600 text-lg">{initials(user.name)}</span>
					</div>
				</div>

				<div>
					<p class="font-medium text-center">{user.name}</p>
					<p class="text-center text-sm">
						<a class="hover:underline" href={mailto(user.email)}>{user.email}</a>
					</p>

					<!-- Show role selection only if the current user is 'board' -->
					{#if currentUserRole === 'board'}
						<div class="mt-2">
							<select on:change={(e) => updateRole(user.id, e.target.value)}>
								<option value="normal" selected={user.role === 'normal'}>Frivillig</option>
								<option value="board" selected={user.role === 'board'}>Styret</option>
							</select>
						</div>
					{/if}
				</div>
			</li>
		{/each}
	</ul>
</section>

<section class="mt-12 space-y-6">
	<Heading>Normal Members</Heading>

	<div class="flex items-center gap-2">
		<input
			type="search"
			class="w-full flex-1 p-2 border rounded"
			placeholder="Search Normal Members"
			bind:value={search}
		/>
	</div>

	<ul class="grid grid-cols-1 md:grid-cols-3 gap-4">
		{#each normalMembers as user}
			<li class="block bg-white border rounded-lg p-4">
				<div class="flex justify-center mb-2">
					<div class="w-16 h-16 bg-gray-200 flex items-center justify-center border rounded-full">
						<span class="font-medium text-gray-600 text-lg">{initials(user.name)}</span>
					</div>
				</div>

				<div>
					<p class="font-medium text-center">{user.name}</p>
					<p class="text-center text-sm">
						<a class="hover:underline" href={mailto(user.email)}>{user.email}</a>
					</p>

					<!-- Show role selection only if the current user is 'board' -->
					{#if currentUserRole === 'board'}
						<div class="mt-2">
							<select on:change={(e) => updateRole(user.id, e.target.value)}>
								<option value="normal" selected={user.role === 'normal'}>Normal</option>
								<option value="board" selected={user.role === 'board'}>Board</option>
							</select>
						</div>
					{/if}
				</div>
			</li>
		{/each}
	</ul>
</section>
