<div class="rounded-xl border-2 bg-background max-w-[400px] mx-auto">
	<div class="p-4">
		<h1 class="text-2xl font-bold text-center mb-2">Logg inn</h1>
		<p class="text-sm text-center text-gray-500">Logg inn for å få tilgang til alle funksjoner</p>
	</div>
	<div class="flex flex-col gap-2 p-4">
		<a
			class="text-center rounded-lg border p-1 font-medium hover:bg-gray-200 hover:border-gray-300 transition-all"
			href="/auth/feide">Fortsett med Feide</a
		>
	</div>
</div>
