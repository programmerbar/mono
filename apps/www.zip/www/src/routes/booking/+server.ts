export function GET() {
	return Response.redirect('https://forms.gle/BLdygdoRJgjMbQZj6');
}
