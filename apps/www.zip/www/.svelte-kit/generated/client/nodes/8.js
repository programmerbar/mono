import * as universal from "../../../../src/routes/(app)/meny/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/(app)/meny/+page.svelte";