import * as universal from "../../../../src/routes/(app)/om-oss/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/(app)/om-oss/+page.svelte";