import * as universal from "../../../../src/routes/(app)/arrangement/[slug]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/(app)/arrangement/[slug]/+page.svelte";