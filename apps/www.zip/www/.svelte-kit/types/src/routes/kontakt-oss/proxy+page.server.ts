// @ts-nocheck
import type { Actions } from './$types';
import { ContactUsSchema } from '$lib/validators';

export const actions = {
	default: async ({ locals, request }: import('./$types').RequestEvent) => {
		const data = await request.formData().then(ContactUsSchema.parse);

		await locals.emailService.sendContactUsEmail(data);

		return { success: true };
	}
};
;null as any as Actions;