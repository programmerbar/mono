// @ts-nocheck
import { dev } from '$app/environment';
import type { Actions } from './$types';

export const actions = {
	default: async ({ locals, cookies }: import('./$types').RequestEvent) => {
		if (!locals.session) {
			return { success: true };
		}

		await locals.auth.invalidateSession(locals.session.id);
		cookies.delete(locals.auth.sessionCookieName, {
			path: '/',
			httpOnly: true,
			secure: !dev
		});

		return { success: true };
	}
};
;null as any as Actions;