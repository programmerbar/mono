// @ts-nocheck
import { getProgrammerbarGroup } from '$lib/api/sanity/programmerbar';
import type { PageLoad } from './$types';

export const load = async () => {
	const programmerbar = await getProgrammerbarGroup();

	return {
		programmerbar
	};
};
;null as any as PageLoad;