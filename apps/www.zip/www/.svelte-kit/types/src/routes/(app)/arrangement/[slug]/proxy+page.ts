// @ts-nocheck
import { getEventBySlug } from '$lib/api/sanity/events';
import { error } from '@sveltejs/kit';
import type { PageLoad } from './$types';

export const load = async ({ params }: Parameters<PageLoad>[0]) => {
	const event = await getEventBySlug(params.slug);

	if (!event) {
		throw error(404, 'Event not found');
	}

	return {
		event
	};
};
