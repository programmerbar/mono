// @ts-nocheck
import { getProducts } from '$lib/api/sanity/products';
import type { PageLoad } from './$types';

export const load = async () => {
	const products = await getProducts();

	return {
		products
	};
};
;null as any as PageLoad;