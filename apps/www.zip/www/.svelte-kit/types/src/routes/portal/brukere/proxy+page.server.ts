// @ts-nocheck
import type { PageServerLoad } from './$types';

export const load = async ({ locals }: Parameters<PageServerLoad>[0]) => {
	const [users, invitations] = await Promise.all([
		locals.userService.findAll(),
		locals.invitationService.findAllUnused()
	]);

	return {
		users,
		invitations
	};
};
