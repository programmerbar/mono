// @ts-nocheck
import type { PageServerLoad } from './$types';

export const load = async ({ locals }: Parameters<PageServerLoad>[0]) => {
	const events = await locals.db.query.events.findMany({
		orderBy: (row, { asc }) => [asc(row.date)],
		with: {
			shifts: true
		}
	});

	return {
		events
	};
};
