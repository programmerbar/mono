// @ts-nocheck

// src/routes/portal/admin/+page.server.ts

import { redirect, fail } from '@sveltejs/kit';
import type { Actions, PageServerLoad } from './$types';
import { UserService } from '$lib/services/user.service';

export const load = async ({ locals }: Parameters<PageServerLoad>[0]) => {
  if (locals.user.role !== 'board') {
    throw redirect(307, '/portal');
  }

  const users = await locals.userService.findAll();

  return {
    users
  };
};

export const actions = {
  updateRole: async ({ request, locals }: import('./$types').RequestEvent) => {
    if (locals.user.role !== 'board') {
      return fail(403, { message: 'Access denied' });
    }

    const formData = await request.formData();
    const userId = formData.get('userId');
    const newRole = formData.get('role');

    if (!userId || !newRole) {
      return fail(400, { message: 'Invalid request' });
    }

    const userService = new UserService(locals.db);
    await userService.updateUserRole(userId.toString(), newRole as 'normal' | 'board');

    return { success: true };
  }
};
;null as any as Actions;